# Databricks notebook source
from pyspark.sql.functions import current_timestamp, input_file_name
from pyspark.sql import SparkSession
from pyspark.sql import DataFrame

def transform_bronze_orders(df: DataFrame):
    return df \
        .withColumn("source_file_name", input_file_name()) \
        .withColumn("ingestion_timestamp", current_timestamp()) \
        .withColumnRenamed("State short", "state_code")

# COMMAND ----------

if __name__ == "_main__" or "dbutils" in globals(): 
    spark = SparkSession.builder.getOrCreate()

    source_path = "abfss://raw@mokopnypoca1.dfs.core.windows.net/orders/"
    checkpoint_path = "abfss://mokopnypoca1.blob.core.windows.net/catalog/transform/bronze/_checkpoints/orders/"
    schema_location = "abfss://mokopnypoca1.blob.core.windows.net/catalog/transform/bronze/_schemas/orders/"
    

    df_raw = spark.read.format("json") \
        .option("header", True) \
        .option("inferSchema", True) \
        .load("abfss://raw@mokopnypoca1.dfs.core.windows.net/orders/")

    df_bronze = transform_bronze_orders(df_raw)

    df_bronze.write.format("delta") \
        .mode("overwrite") \
        .saveAsTable("bronze.orders")