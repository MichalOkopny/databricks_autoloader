# Databricks notebook source
from pyspark.sql.functions import current_timestamp, input_file_name
from pyspark.sql import SparkSession
from pyspark.sql import DataFrame

def transform_bronze_mapping(df: DataFrame):
    return df \
        .withColumn("source_file_name", input_file_name()) \
        .withColumn("ingestion_timestamp", current_timestamp()) \
        .withColumnRenamed("State short", "state_code")

# COMMAND ----------

if __name__ == "_main__" or "dbutils" in globals():


    spark = SparkSession.builder.getOrCreate()

    source_path = "abfss://raw@mokopnypoca1.dfs.core.windows.net/city_state_mapping/"
    checkpoint_path = "abfss://catalog@mokopnypoca1.dfs.core.windows.net/transform/bronze/_checkpoints/city_state_mapping/"
    schema_location = "abfss://catalog@mokopnypoca1.dfs.core.windows.net/transform/bronze/_schemas/city_state_mapping/"

    df_raw = spark.readStream.format("cloudFiles")\
        .option("cloudFiles.format", "csv") \
        .option("cloudFiles.schemaLocation", schema_location)\
        .option("header", True) \
        .load(source_path)

    df_bronze = transform_bronze_mapping(df_raw)
    
    df_bronze.writeStream.format("delta") \
        .option("checkpointLocation", checkpoint_path) \
        .option("mergeSchema", True)\
        .trigger(availableNow=True)\
        .outputMode("append") \
        .toTable("bronze.city_state_mapping")