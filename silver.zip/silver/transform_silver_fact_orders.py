# Databricks notebook source
from pyspark.sql.functions import col, to_date, lower

def prepare_employee_dim(df_dim_emp):
    """
    Prepares the employee dimension DataFrame for joining.
    
    Parameters:
        df_dim_emp (DataFrame): Employee dimension table.
    
    Returns:
        DataFrame: DataFrame with employee email and foreign key.
    """
    return df_dim_emp.select(
        col("email"),
        col("PK").alias("employee_fk")
    )

# COMMAND ----------

def prepare_date_dim(dim_date):
    """
    Prepares the date dimension DataFrame for joining.
    
    Parameters:
        dim_date (DataFrame): Date dimension table.
    
    Returns:
        DataFrame: DataFrame with date and foreign key.
    """
    return dim_date.select(
        col("date"),
        col("PK").alias("date_fk")
    )

# COMMAND ----------

def normalize_orders(df_bronze_orders):
    """
    Normalizes string columns in the orders DataFrame.
    
    Parameters:
        df_bronze_orders (DataFrame): Raw orders table.
    
    Returns:
        DataFrame: DataFrame with normalized employee_email and product_category.
    """
    return df_bronze_orders \
        .withColumn("employee_email", lower(col("employee_email"))) \
        .withColumn("product_category", lower(col("product_category")))


# COMMAND ----------

def transform_orders(df_bronze_orders, dim_date, df_dim_emp):
    """
    Transforms raw orders into a fact table by joining with employee and date dimensions.
    
    Parameters:
        df_bronze_orders (DataFrame): Raw orders table.
        dim_date (DataFrame): Date dimension table.
        df_dim_emp (DataFrame): Employee dimension table.
    
    Returns:
        DataFrame: Final fact table for orders.
    """
    df_emp_prepared = prepare_employee_dim(df_dim_emp)
    df_date_prepared = prepare_date_dim(dim_date)
    df_transform_orders = normalize_orders(df_bronze_orders)

    df_fact = df_transform_orders.join(
        df_emp_prepared,
        df_transform_orders.employee_email == df_emp_prepared.email,
        "left"
    )
    df_final_fact = df_fact.join(
        df_date_prepared,
        col("time").cast("date") == col("date"),
        "left"
    ).select(
        col("id").alias("order_id"),
        col("date_fk"),
        col("employee_fk"),
        col("quantity").cast("int"),
        col("product_id"),
        col("total_price").cast("double"),
        col("unit_price").cast("double")
    )
    return df_final_fact

# COMMAND ----------

if __name__ == "__main__":
    from pyspark.sql import SparkSession

    spark = SparkSession.builder.getOrCreate()
    df_bronze_orders = spark.table("bronze.orders")
    df_dim_date = spark.table("silver.dim_date")
    df_dim_emp = spark.table("silver.dim_employees")

    df_final_fact = transform_orders(df_bronze_orders, df_dim_date, df_dim_emp)

    df_final_fact.write.format("delta") \
        .mode("overwrite") \
        .saveAsTable("silver.fact_orders")